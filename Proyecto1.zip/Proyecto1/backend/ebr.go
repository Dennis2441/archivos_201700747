package main

// Estructura para el Extended Boot Record (EBR)
type EBR struct {
	Mount byte     // Indica si la partición está montada o no
	Fit   byte     // Tipo de ajuste de la partición (B, F, W)
	Start int64    // Indica en qué byte del disco inicia la partición
	Size  int64    // Tamaño total de la partición en bytes
	Next  int64    // Byte en el que está el próximo EBR (-1 si no hay siguiente)
	Name  [16]byte // Nombre de la partición
}
