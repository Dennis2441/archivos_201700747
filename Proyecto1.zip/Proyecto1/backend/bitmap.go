package main

// Estructura del bitmap de inodos
type BitmapInodes struct {
	Bitmap []byte // Array de bytes representando el estado de los inodos
}

// Estructura del bitmap de bloques
type BitmapBlocks struct {
	Bitmap []byte // Array de bytes representando el estado de los bloques
}
