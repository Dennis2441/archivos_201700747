package main

import (
	"encoding/binary"
	"os"
	"strings"
	"time"
)

// Crea un nuevo disco
func CreateDisk(path string, size int64, unit string) error {
	var byteSize int64
	switch strings.ToUpper(unit) {
	case "K":
		byteSize = size * 1024
	case "M":
		byteSize = size * 1024 * 1024
	default:
		byteSize = size * 1024 * 1024 // Asumir por defecto megabytes
	}

	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()

	// Inicializar el MBR
	mbr := MBR{
		Size:          byteSize,
		CreationDate:  time.Now(),
		DiskSignature: int32(time.Now().UnixNano()),
		DiskFit:       'F', // Ajuste por defecto
	}

	// Inicializar particiones
	for i := 0; i < 4; i++ {
		mbr.Partitions[i] = Partition{
			Status:      0,
			Type:        'P',
			Fit:         'F',
			Start:       -1,
			Size:        0,
			Name:        [16]byte{}, // Inicializa el nombre vacío
			Correlative: i + 1,
			ID:          [4]byte{}, // Inicializa ID vacío
		}
	}

	// Escribir el MBR en el disco
	if err := binary.Write(file, binary.LittleEndian, mbr); err != nil {
		return err
	}

	// Inicializar el superbloque
	superBlock := SuperBlock{
		FilesystemType:  0xEF53, // Identificación del sistema de archivos (por ejemplo, EXT2)
		InodesCount:     100,
		BlocksCount:     int32(byteSize / 4096), // Tamaño de bloque estándar 4KB
		FreeBlocksCount: int32(byteSize / 4096),
		FreeInodesCount: 100,
		Mtime:           time.Now(),
		Umtime:          time.Now(),
		MntCount:        0,
		Magic:           0xEF53,
		InodeSize:       128,
		BlockSize:       4096,
		FirstInode:      1,
		FirstBlock:      1,
		BmInodeStart:    1024,
		BmBlockStart:    2048,
		InodeStart:      3072,
		BlockStart:      4096,
	}

	// Escribir el superbloque en el disco
	if _, err := file.Seek(512, 0); err != nil { // Moverse a la posición correcta
		return err
	}
	if err := binary.Write(file, binary.LittleEndian, superBlock); err != nil {
		return err
	}

	return nil
}

// Elimina un disco
func RemoveDisk(path string) error {
	err := os.Remove(path)
	if err != nil {
		return err
	}
	return nil
}

// Aquí puedes implementar la lógica para las funciones Fdisk, Mount, Mkfs y Cat.
