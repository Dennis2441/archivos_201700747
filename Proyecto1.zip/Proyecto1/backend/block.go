package main

// Estructura para bloques de archivos
type BlockFile struct {
	Content [64]byte // Contenido del archivo
}

// Estructura para bloques de carpetas
type BlockFolder struct {
	Content [4]Content // Array con el contenido de la carpeta
}

type Content struct {
	Name  [12]byte // Nombre del archivo o carpeta
	Inodo int      // Inodo asociado
}

// Estructura para bloques de apuntadores
type BlockPointer struct {
	Pointers [16]int // Punteros a bloques (de archivo o carpeta)
}
