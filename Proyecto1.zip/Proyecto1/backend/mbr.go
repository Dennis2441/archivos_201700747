package main

import (
	"time"
)

// Estructura para el MBR
type MBR struct {
	Size          int64        // Tamaño total del disco en bytes
	CreationDate  time.Time    // Fecha y hora de creación del disco
	DiskSignature int32        // Número random que identifica de forma única a cada disco
	DiskFit       byte         // Tipo de ajuste de la partición (B, F, W)
	Partitions    [4]Partition // Estructura con información de las 4 particiones
}
