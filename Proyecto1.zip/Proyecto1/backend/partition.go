package main

// Estructura para una partición
type Partition struct {
	Status      byte     // Indica si la partición está montada o no
	Type        byte     // Indica el tipo de partición (P: primaria, E: extendida)
	Fit         byte     // Tipo de ajuste de la partición (B: Best, F: First, W: Worst)
	Start       int64    // Indica en qué byte del disco inicia la partición
	Size        int64    // Tamaño total de la partición en bytes
	Name        [16]byte // Nombre de la partición
	Correlative int      // Indica el correlativo de la partición
	ID          [4]byte  // ID de la partición generada al montar esta partición
}
